package com.proandroidflash;

import air.app.AppEntry;
import android.os.Bundle;
import android.content.Intent;

public class MainApp extends AppEntry {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		try
		{
			Intent srv = new Intent(this, TestService.class);
			startService(srv);
		}
		catch (Exception e)
		{
			// service could not be started
		}

		super.onCreate(savedInstanceState);
/*		
		System.out.println("test test");
		super.onCreate(arg0);
*/
	}
}
